#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>
#include <Geode/ui/ScrollLayer.hpp>
#include <Geode/ui/Notification.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/EditorPauseLayer.hpp>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <unordered_map>

using namespace geode::prelude;
namespace fs = std::filesystem;

namespace {

enum Role { R_SOLID = 0, R_HAZARD = 1, R_SLOPE = 2, R_DECO = 3, R_TRIG = 4, R_NONE = -1 };
constexpr float CELL = 30.f;

// ---------- helpers ----------

std::vector<std::string> split(std::string const& s, char d) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == d) { out.push_back(cur); cur.clear(); }
        else cur += c;
    }
    out.push_back(cur);
    return out;
}

struct Obj {
    std::vector<std::pair<std::string, std::string>> kv;
    bool has(char const* k) const { for (auto& p : kv) if (p.first == k) return true; return false; }
    std::string get(char const* k) const { for (auto& p : kv) if (p.first == k) return p.second; return ""; }
    void set(char const* k, std::string const& v) {
        for (auto& p : kv) if (p.first == k) { p.second = v; return; }
        kv.push_back({k, v});
    }
    float f(char const* k) const { auto s = get(k); return s.empty() ? 0.f : std::strtof(s.c_str(), nullptr); }
    int i(char const* k) const { auto s = get(k); return s.empty() ? 0 : std::atoi(s.c_str()); }
    std::string str() const {
        std::string o;
        for (size_t n = 0; n < kv.size(); n++) {
            if (n) o += ',';
            o += kv[n].first + ',' + kv[n].second;
        }
        return o;
    }
};

Obj parseObj(std::string const& s) {
    Obj o;
    auto t = split(s, ',');
    for (size_t n = 0; n + 1 < t.size(); n += 2) o.kv.push_back({t[n], t[n + 1]});
    return o;
}

std::string fmt(float v) {
    char b[32];
    std::snprintf(b, sizeof b, "%.2f", v);
    return b;
}

// objects of a level string (decompresses if needed, drops the header)
std::vector<std::string> levelObjects(std::string s) {
    if (s.find(';') == std::string::npos) s = std::string(ZipUtils::decompressString(s, false, 11));
    auto parts = split(s, ';');
    std::vector<std::string> out;
    for (size_t n = 1; n < parts.size(); n++) if (!parts[n].empty()) out.push_back(parts[n]);
    return out;
}

std::string safeName(std::string n) {
    for (auto& c : n) {
        if (std::string("\\/:*?\"<>|").find(c) != std::string::npos || (unsigned char)c < 32) c = '_';
    }
    if (n.empty()) n = "level";
    return n;
}

int roleFromType(GameObjectType t) {
    switch (t) {
        case GameObjectType::Solid: return R_SOLID;
        case GameObjectType::Hazard: return R_HAZARD;
        case GameObjectType::Slope: return R_SLOPE;
        case GameObjectType::Decoration: return R_DECO;
        default: return R_NONE;
    }
}

int roleOf(int id, std::unordered_map<int, int>& cache) {
    // visual triggers only: color, move, pulse, alpha, toggle, rotate, follow, scale, shake
    static const std::set<int> trig{899, 901, 1006, 1007, 1049, 1346, 1347, 2067, 1520};
    if (trig.count(id)) return R_TRIG;
    auto it = cache.find(id);
    if (it != cache.end()) return it->second;
    int r = R_NONE;
    if (auto o = GameObject::createWithKey(id)) r = roleFromType(o->m_objectType);
    cache[id] = r;
    return r;
}

struct Item { Obj o; int role; };

// ---------- saving ----------

bool saveDecor(PlayLayer* pl, std::string& err) {
    auto lvl = pl->m_level;
    std::unordered_map<int, int> cache;
    std::vector<Item> items;
    float minx = 1e9f, miny = 1e9f;
    int decos = 0;

    for (auto& s : levelObjects(std::string(lvl->m_levelString))) {
        Obj o = parseObj(s);
        int r = roleOf(o.i("1"), cache);
        if (r == R_NONE) continue;
        if (r != R_TRIG) {
            minx = std::min(minx, o.f("2"));
            miny = std::min(miny, o.f("3"));
        }
        if (r == R_DECO) decos++;
        items.push_back({o, r});
    }
    if (decos == 0) { err = "No decoration found"; return false; }

    std::string name = safeName(std::string(lvl->m_levelName));
    auto dir = Mod::get()->getSaveDir() / "saves" / name;
    std::error_code ec;
    fs::create_directories(dir, ec);
    std::ofstream f(dir / "decor.txt");
    if (!f) { err = "Cannot write file"; return false; }

    f << "#level=" << name << "\n";
    f << "#author=" << std::string(lvl->m_creatorName) << "\n";
    f << "#id=" << lvl->m_levelID.value() << "\n";
    for (auto& it : items) {
        Obj o = it.o;
        o.set("2", fmt(o.f("2") - minx));
        o.set("3", fmt(o.f("3") - miny));
        f << it.role << "|" << o.str() << "\n";
    }
    return true;
}

// ---------- fitting ----------

using Cell = std::pair<int, int>;
int cellOf(float v) { return (int)std::floor(v / CELL); }

// bit0 top free, bit1 right free, bit2 bottom free, bit3 left free
int exposure(std::set<Cell> const& solids, int cx, int cy) {
    int m = 0;
    if (!solids.count({cx, cy + 1})) m |= 1;
    if (!solids.count({cx + 1, cy})) m |= 2;
    if (!solids.count({cx, cy - 1})) m |= 4;
    if (!solids.count({cx - 1, cy})) m |= 8;
    return m;
}

int rotQ(float r) {
    int q = (int)std::lround(r / 90.f) % 4;
    return q < 0 ? q + 4 : q;
}

std::string anchorKey(int cls, int mask, int rq, int fx, int fy) {
    if (cls == R_SOLID) rq = fx = fy = 0; // rotation does not matter for plain blocks
    return std::to_string(cls) + "|" + std::to_string(mask) + "|" + std::to_string(rq) + "|" +
           std::to_string(fx) + "|" + std::to_string(fy);
}

struct Anchor {
    int cls, mask, rq, fx, fy;
    float x, y;
    std::vector<int> deco;
};

// shift group / color IDs so they do not collide with the target level
void remap(Obj& o, int gOff, int cOff) {
    auto grp = [&](int n) { return (n > 0 && n + gOff <= 9999) ? n + gOff : n; };
    auto col = [&](int n) { return (n >= 1 && n < 1000 && n + cOff < 1000) ? n + cOff : n; };

    for (char const* k : {"57"}) {
        if (!o.has(k)) continue;
        auto parts = split(o.get(k), '.');
        std::string res;
        for (size_t n = 0; n < parts.size(); n++) {
            if (n) res += '.';
            res += std::to_string(grp(std::atoi(parts[n].c_str())));
        }
        o.set(k, res);
    }
    if (o.has("71")) o.set("71", std::to_string(grp(o.i("71"))));

    int id = o.i("1");
    if (id == 899) {
        if (o.has("23")) o.set("23", std::to_string(col(o.i("23"))));
    } else if (id == 1006) {
        if (o.has("51")) {
            int v = o.i("51");
            o.set("51", std::to_string(o.get("52") == "1" ? grp(v) : col(v)));
        }
    } else if (o.has("51")) {
        o.set("51", std::to_string(grp(o.i("51"))));
    }
    for (char const* k : {"21", "22"}) {
        if (o.has(k)) o.set(k, std::to_string(col(o.i(k))));
    }
}

int applyDecor(fs::path const& file, std::string& err) {
    auto lel = LevelEditorLayer::get();
    if (!lel) { err = "Editor not found"; return 0; }

    // 1. load saved decor
    std::vector<Item> items;
    {
        std::ifstream f(file);
        if (!f) { err = "Cannot read file"; return 0; }
        std::string line;
        while (std::getline(f, line)) {
            if (line.empty() || line[0] == '#') continue;
            auto bar = line.find('|');
            if (bar == std::string::npos) continue;
            items.push_back({parseObj(line.substr(bar + 1)), std::atoi(line.substr(0, bar).c_str())});
        }
    }

    // 2. source anchors (blocks / spikes / slopes) and their free sides
    std::set<Cell> srcSolids;
    for (auto& it : items) {
        if (it.role == R_SOLID) srcSolids.insert({cellOf(it.o.f("2")), cellOf(it.o.f("3"))});
    }
    std::vector<Anchor> anchors;
    std::map<Cell, std::vector<int>> anchorGrid;
    for (auto& it : items) {
        if (it.role < R_SOLID || it.role > R_SLOPE) continue;
        Anchor a;
        a.cls = it.role;
        a.x = it.o.f("2");
        a.y = it.o.f("3");
        int cx = cellOf(a.x), cy = cellOf(a.y);
        a.mask = exposure(srcSolids, cx, cy);
        a.rq = rotQ(it.o.f("6"));
        a.fx = it.o.i("4") ? 1 : 0;
        a.fy = it.o.i("5") ? 1 : 0;
        anchorGrid[{cx, cy}].push_back((int)anchors.size());
        anchors.push_back(a);
    }
    if (anchors.empty()) { err = "No blocks saved with this decor"; return 0; }

    // 3. attach every decor object to the nearest anchor (< 45 units)
    std::vector<int> loose; // decor without an anchor + triggers
    for (int n = 0; n < (int)items.size(); n++) {
        auto& it = items[n];
        if (it.role == R_TRIG) { loose.push_back(n); continue; }
        if (it.role != R_DECO) continue;
        float x = it.o.f("2"), y = it.o.f("3");
        int cx = cellOf(x), cy = cellOf(y), best = -1;
        float bd = 45.f * 45.f;
        for (int dx = -2; dx <= 2; dx++) for (int dy = -2; dy <= 2; dy++) {
            auto g = anchorGrid.find({cx + dx, cy + dy});
            if (g == anchorGrid.end()) continue;
            for (int ai : g->second) {
                float ddx = anchors[ai].x - x, ddy = anchors[ai].y - y;
                float d = ddx * ddx + ddy * ddy;
                if (d < bd) { bd = d; best = ai; }
            }
        }
        if (best >= 0) anchors[best].deco.push_back(n);
        else loose.push_back(n);
    }

    std::map<std::string, std::vector<int>> byKey;
    for (int n = 0; n < (int)anchors.size(); n++) {
        auto& a = anchors[n];
        byKey[anchorKey(a.cls, a.mask, a.rq, a.fx, a.fy)].push_back(n);
    }

    // 4. target supports in the editor
    struct T { int cls; float x, y; int rq, fx, fy; };
    std::vector<T> targets;
    std::set<Cell> tSolids;
    {
        CCArrayExt<GameObject*> objs(lel->m_objects);
        for (auto obj : objs) {
            int r = roleFromType(obj->m_objectType);
            if (r < R_SOLID || r > R_SLOPE) continue;
            T t{r, obj->getPositionX(), obj->getPositionY(), rotQ(obj->getRotation()),
                obj->isFlipX() ? 1 : 0, obj->isFlipY() ? 1 : 0};
            targets.push_back(t);
            if (r == R_SOLID) tSolids.insert({cellOf(t.x), cellOf(t.y)});
        }
    }

    // 5. ID offsets so groups and colors do not collide
    int gMax = 0, cMax = 0;
    for (auto& s : levelObjects(std::string(lel->getLevelString()))) {
        Obj o = parseObj(s);
        for (auto& g : split(o.get("57"), '.')) gMax = std::max(gMax, std::atoi(g.c_str()));
        gMax = std::max({gMax, o.i("71")});
        for (char const* k : {"21", "22"}) {
            int c = o.i(k);
            if (c < 1000) cMax = std::max(cMax, c);
        }
    }

    // 6. place decor on targets
    std::string out;
    int count = 0;
    float ox = 0.f, oy = 0.f;
    if (!targets.empty()) {
        ox = oy = 1e9f;
        for (auto& t : targets) { ox = std::min(ox, t.x); oy = std::min(oy, t.y); }
    } else {
        auto lay = lel->m_objectLayer;
        float sc = lay->getScale();
        ox = -lay->getPositionX() / sc;
        oy = -lay->getPositionY() / sc;
    }

    for (auto& t : targets) {
        int cx = cellOf(t.x), cy = cellOf(t.y);
        int mask = exposure(tSolids, cx, cy);
        int pick = -1;
        auto it = byKey.find(anchorKey(t.cls, mask, t.rq, t.fx, t.fy));
        if (it != byKey.end()) {
            unsigned h = ((unsigned)cx * 73856093u) ^ ((unsigned)cy * 19349663u);
            pick = it->second[h % it->second.size()];
        } else {
            // fallback: same type, rotation and flips, sides differ by at most one
            for (int n = 0; n < (int)anchors.size(); n++) {
                auto& a = anchors[n];
                if (a.cls != t.cls) continue;
                if (t.cls != R_SOLID && (a.rq != t.rq || a.fx != t.fx || a.fy != t.fy)) continue;
                int diff = a.mask ^ mask;
                if (diff && (diff & (diff - 1)) == 0) { pick = n; break; }
            }
        }
        if (pick < 0) continue;
        auto& a = anchors[pick];
        for (int di : a.deco) {
            Obj d = items[di].o;
            d.set("2", fmt(t.x + d.f("2") - a.x));
            d.set("3", fmt(t.y + d.f("3") - a.y));
            remap(d, gMax, cMax);
            out += d.str() + ";";
            count++;
        }
    }

    // loose decor and triggers: placed once, relative to the bottom-left of your blocks
    for (int n : loose) {
        Obj d = items[n].o;
        d.set("2", fmt(ox + d.f("2")));
        d.set("3", fmt(oy + d.f("3")));
        remap(d, gMax, cMax);
        out += d.str() + ";";
        count++;
    }

    if (out.empty()) { err = "Nothing to place"; return 0; }

    // NOTE: signatures may differ between bindings versions; see build log if it fails
    auto arr = lel->createObjectsFromString(out, true, true);
    if (arr) lel->m_undoObjects->addObject(UndoObject::createWithArray(arr, UndoCommand::Paste));
    return count;
}

} // namespace

// ---------- UI: list of saved decor ----------

class DecorListPopup : public geode::Popup<> {
protected:
    bool setup() override {
        this->setTitle("Saved decor");
        std::vector<std::string> names;
        auto dir = Mod::get()->getSaveDir() / "saves";
        std::error_code ec;
        if (fs::exists(dir, ec)) {
            for (auto& e : fs::directory_iterator(dir, ec)) {
                if (e.is_directory(ec) && fs::exists(e.path() / "decor.txt", ec))
                    names.push_back(e.path().filename().string());
            }
        }
        std::sort(names.begin(), names.end());

        auto size = m_mainLayer->getContentSize();
        auto scroll = ScrollLayer::create({260.f, 150.f});
        scroll->setPosition({(size.width - 260.f) / 2.f, 20.f});
        m_mainLayer->addChild(scroll);

        float h = std::max(150.f, names.size() * 36.f);
        scroll->m_contentLayer->setContentSize({260.f, h});
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        menu->setContentSize({260.f, h});
        for (size_t i = 0; i < names.size(); i++) {
            auto name = names[i];
            auto spr = ButtonSprite::create(name.c_str(), 240, true, "bigFont.fnt", "GJ_button_01.png", 30.f, .6f);
            auto btn = CCMenuItemExt::createSpriteExtra(spr, [this, name](CCMenuItemSpriteExtra*) {
                std::string err;
                int n = applyDecor(Mod::get()->getSaveDir() / "saves" / name / "decor.txt", err);
                if (n > 0) Notification::create("Placed " + std::to_string(n) + " objects (Ctrl+Z / undo to revert)", NotificationIcon::Success)->show();
                else Notification::create(err, NotificationIcon::Error)->show();
                this->onClose(nullptr);
            });
            btn->setPosition({130.f, h - 18.f - i * 36.f});
            menu->addChild(btn);
        }
        scroll->m_contentLayer->addChild(menu);
        scroll->moveToTop();

        if (names.empty()) {
            auto l = CCLabelBMFont::create("Nothing saved yet", "bigFont.fnt");
            l->setScale(.5f);
            l->setPosition(size / 2);
            m_mainLayer->addChild(l);
        }
        return true;
    }

public:
    static DecorListPopup* create() {
        auto ret = new DecorListPopup();
        if (ret->initAnchored(300.f, 220.f)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

// ---------- hooks ----------

class $modify(DecorPause, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();
        auto pl = PlayLayer::get();
        if (!pl || pl->m_level->m_levelType == GJLevelType::Editor) return; // only other people's levels

        auto menu = CCMenu::create();
        auto btn = CCMenuItemSpriteExtra::create(ButtonSprite::create("Copy decor"), this, menu_selector(DecorPause::onCopyDecor));
        btn->getNormalImage()->setScale(.6f);
        menu->addChild(btn);
        menu->setPosition({70.f, 30.f});
        this->addChild(menu);
    }

    void onCopyDecor(CCObject*) {
        auto pl = PlayLayer::get();
        if (!pl) return;
        std::string err;
        if (saveDecor(pl, err)) Notification::create("Decor saved! Credit the author.", NotificationIcon::Success)->show();
        else Notification::create(err, NotificationIcon::Error)->show();
    }
};

class $modify(DecorEditorPause, EditorPauseLayer) {
    bool init(LevelEditorLayer* lel) {
        if (!EditorPauseLayer::init(lel)) return false;
        auto menu = CCMenu::create();
        auto btn = CCMenuItemSpriteExtra::create(ButtonSprite::create("Decor"), this, menu_selector(DecorEditorPause::onDecor));
        btn->getNormalImage()->setScale(.6f);
        menu->addChild(btn);
        menu->setPosition({50.f, 30.f});
        this->addChild(menu);
        return true;
    }

    void onDecor(CCObject*) {
        if (auto p = DecorListPopup::create()) p->show();
    }
};
